const aws = require('aws-sdk')
const ses = new aws.SES({
  region: 'eu-west-1'
})

exports.handler = async function (event, context, callback) {
  // SEND EMAIL
  const eParams = {
    Destination: {
      ToAddresses: ['jeanphilippe.bourgeon@gmail.com']
    },
    Message: {
      Body: {
        Text: {
          Data: `Message de : ${event.sender}

---

${event.content}`
        }
      },
      Subject: {
        Data: `${event.subject}`
      }
    },
    Source: 'no-reply@rgpday.com'
  }

  ses.sendEmail(eParams, (error, data) => {
    if (error) {
      callback(JSON.stringify({ success: false, message: 'Email not sent', error }), event)
    } else {
      callback(null, JSON.stringify({ success: true, message: 'Email sent', data, event }))
    }
  })
}
