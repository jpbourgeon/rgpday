const aws = require('aws-sdk')
const ses = new aws.SES({
  region: 'eu-west-1'
})

exports.handler = async function (event, context) {
  const eParams = {
    Destination: {
      ToAddresses: ['jeanphilippe.bourgeon@gmail.com']
    },
    Message: {
      Body: {
        Text: {
          Data: `Message de : ${event.sender}

---

${event.content}`
        }
      },
      Subject: {
        Data: `${event.subject}`
      }
    },
    Source: 'no-reply@rgpday.com'
  }
  try {
    await ses.sendEmail(eParams, (err) => {
      if (err) {
        context.done({ status: 500, error: err })
      } else {
        context.done({ status: 200, message: 'Email sent' })
      }
    })
  } catch (err) { console.log(err) }
}
