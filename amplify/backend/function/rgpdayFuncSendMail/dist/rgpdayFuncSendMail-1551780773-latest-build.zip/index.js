const aws = require('aws-sdk')

exports.handler = async function (event, context, callback) {
  // VERIFY RECAPTCHA
  const lambda = new aws.Lambda({ region: 'eu-west-1' })
  lambda.invoke({
    FunctionName: `rgpdayFuncVerifyRecaptcha-${process.env.ENV || 'dev'}`,
    Payload: JSON.stringify({ recaptcha: event.recaptcha }),
    InvocationType: 'RequestResponse'
  }, (error, data) => {
    if (error) {
      callback(JSON.stringify(error), event)
    } else {
      const payload = JSON.parse(data.Payload)
      console.log(payload)
      if (payload === null) {
        const message =
        // START MESSAGE TEMPLATE
        `Message de : ${event.sender}
        
        ---
        
        ${event.content}`
        // END MESSAGE TEMPLATE

        const eParams = {
          Destination: {
            ToAddresses: ['jeanphilippe.bourgeon@gmail.com']
          },
          Message: {
            Body: {
              Text: {
                Data: message
              }
            },
            Subject: {
              Data: `${event.subject}`
            }
          },
          Source: 'no-reply@rgpday.com'
        }

        // SEND EMAIL
        const ses = new aws.SES({ region: 'eu-west-1' })
        ses.sendEmail(eParams, (error, data) => {
          if (error) {
            callback(JSON.stringify({ success: false, message: 'Email not sent', error }), event)
          } else {
            callback(null, JSON.stringify({ success: true, message: 'Email sent', data, event }))
          }
        })
      } else {
        callback(payload.errorMessage, event)
      }
    }
  })
}
