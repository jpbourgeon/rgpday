const aws = require('aws-sdk')
const lambda = new aws.Lambda({ region: 'eu-west-1' })
const ses = new aws.SES({ region: 'eu-west-1' })

exports.handler = async function (event, context, callback) {
  // VERIFY RECAPTCHA
  lambda.invoke({
    FunctionName: `rgpdayFuncVerifyRecaptcha-${process.env.ENV || 'dev'}`,
    Payload: JSON.stringify({ recaptcha: event.recaptcha }),
    InvocationType: 'RequestResponse'
  }, (error, data) => {
    if (error) {
      callback(new Error('lambda.invoke error'), { success: false })
    } else {
      const payload = JSON.parse(data.Payload)
      console.log(payload)
      if (typeof payload.errorType !== 'undefined') {
        callback(new Error('ReCaptcha verification failed'), { success: false })
      } else {
        const Data =
// START MESSAGE TEMPLATE
`Message de : ${event.sender}

---

${event.content}`
// END MESSAGE TEMPLATE
        const eParams = {
          Destination: {
            ToAddresses: ['jeanphilippe.bourgeon@gmail.com']
          },
          Message: {
            Body: {
              Text: {
                Data
              }
            },
            Subject: {
              Data: `${event.subject}`
            }
          },
          Source: 'no-reply@rgpday.com'
        }
        // SEND EMAIL
        ses.sendEmail(eParams, (error, data) => {
          if (error) {
            callback(new Error('Email not sent'), { success: false })
          } else {
            callback(null, { success: true })
          }
        })
      }
    }
  })
}
