/* global fetch */
const aws = require('aws-sdk')
const ses = new aws.SES({
  region: 'eu-west-1'
})

exports.handler = async function (event, context) {
  // RECAPTCHA VERIFICATION
  const RECAPTCHA_SECRET = process.env.RECAPTCHA_SECRET || require('./secret_env.json').RECAPTCHA_SECRET
  console.log({ RECAPTCHA_SECRET })
  if (!RECAPTCHA_SECRET) {
    context.fail({ status: 400, message: 'Unauthorized' })
    context.done()
  }
  const body = JSON.stringify({ secret: RECAPTCHA_SECRET, response: event.recaptcha })
  console.log(body)
  const rawResponse = await fetch('https://www.google.com/recaptcha/api/siteverify', {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    },
    secret: RECAPTCHA_SECRET,
    response: event.recaptcha
  })
  const content = await rawResponse.json()
  console.log(content)
  context.done()

  // SEND EMAIL
  const eParams = {
    Destination: {
      ToAddresses: ['jeanphilippe.bourgeon@gmail.com']
    },
    Message: {
      Body: {
        Text: {
          Data: `Message de : ${event.sender}

---

${event.content}`
        }
      },
      Subject: {
        Data: `${event.subject}`
      }
    },
    Source: 'no-reply@rgpday.com'
  }

  ses.sendEmail(eParams, (err) => {
    if (err) {
      context.fail({ status: 500, error: err })
      context.done()
    } else {
      context.succeed({ status: 200, message: 'Email sent' })
      context.done()
    }
  })
}
