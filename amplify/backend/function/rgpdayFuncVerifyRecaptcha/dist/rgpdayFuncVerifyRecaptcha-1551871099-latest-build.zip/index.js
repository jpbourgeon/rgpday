// const fetch = require('node-fetch')
const request = require('sync-request')

// exports.handler = async function (event, context, callback) {
exports.handler = function (event, context, callback) {
  const RECAPTCHA_SECRET = require('./secret_env.json').RECAPTCHA_SECRET
  if (!RECAPTCHA_SECRET) {
    callback(new Error('RECAPTCHA_SECRET is missing'), { success: false })
  } else {
    const rawResponse = request('POST', 'https://www.google.com/recaptcha/api/siteverify', {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: `secret=${RECAPTCHA_SECRET}&response=${event.recaptcha}`,
      timeout: 4000
    })
    // const rawResponse = await fetch('https://www.google.com/recaptcha/api/siteverify', {
    //   method: 'POST',
    //   headers: {
    //     'Accept': 'application/json',
    //     'Content-Type': 'application/x-www-form-urlencoded'
    //   },
    //   body: `secret=${RECAPTCHA_SECRET}&response=${event.recaptcha}`
    // })
    const verification = JSON.parse(rawResponse)
    if (
      verification.success &&
      verification.score > 0.5 &&
      verification.action === 'contact' &&
      (
        verification.hostname === 'localhost' ||
        verification.hostname.indexOf('rgpday.com') !== -1 ||
        verification.hostname.indexOf('amplifyapp.com') !== -1
      )
    ) {
      callback(null, { success: true })
    } else {
      // RECAPTCHA verification failed
      callback(new Error('ReCaptcha verification failed'), { success: false })
    }
  }
}
